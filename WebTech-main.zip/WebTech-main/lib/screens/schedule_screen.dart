import 'package:flutter/material.dart';

class ScheduleScreen extends StatelessWidget {
  const ScheduleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> todayTasks = [
      "Study Flutter at 10:00 AM",
      "Complete assignment at 2:00 PM",
    ];

    final List<String> upcomingTasks = [
      "Project submission on 20 April",
      "Viva preparation on 21 April",
    ];

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Schedule"),
          backgroundColor: Colors.deepOrange,
          bottom: const TabBar(
            tabs: [
              Tab(text: "Today"),
              Tab(text: "Upcoming"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              itemCount: todayTasks.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const Icon(Icons.today),
                  title: Text(todayTasks[index]),
                );
              },
            ),
            ListView.builder(
              itemCount: upcomingTasks.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const Icon(Icons.upcoming),
                  title: Text(upcomingTasks[index]),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}